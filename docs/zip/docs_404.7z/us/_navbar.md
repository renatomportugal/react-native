* Getting started

  * [Quick start](/us/quickstart.md)
  * [Writing more pages](us/more-pages.md)
  * [Custom navbar](us/custom-navbar.md)
  * [Cover page](us/cover.md)

* Configuration
  * [Configuration](us/configuration.md)
  * [Themes](us/themes.md)
  * [Using plugins](us/plugins.md)
  * [Markdown configuration](us/markdown.md)
  * [Language highlight](us/language-highlight.md)

* [:us:](/us/)